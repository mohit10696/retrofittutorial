package com.example.retrofittutorial;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;

import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface PostInterface {
    String JSONURL = "https://api.ocr.space/parse/";

    @Multipart
    @POST("image")
    Call<String> getUserLogin(
            @Part("apikey") RequestBody apikey,
           //@Part("password") RequestBody password,
            @Part MultipartBody.Part file
    );
}
