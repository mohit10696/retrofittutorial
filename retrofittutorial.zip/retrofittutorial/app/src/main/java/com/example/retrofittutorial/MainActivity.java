package com.example.retrofittutorial;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class MainActivity extends AppCompatActivity {
    private EditText etUname, etPass;
    private Button btn,imagebutton;
    public static String firstName="abcd",filename, hobby="not uploadad";
    public InputStream is;
    private static final int INTENT_REQUEST_CODE = 100;
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imagebutton =  findViewById(R.id.button1);
        etUname = findViewById(R.id.etusername);
        etPass = findViewById(R.id.etpassword);
        btn = findViewById(R.id.btn);
        imagebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);

                intent.setType("image/jpeg");
                try {
                    startActivityForResult(intent, INTENT_REQUEST_CODE);

                } catch (ActivityNotFoundException e) {

                    e.printStackTrace();
                }
            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    loginUser(getBytes(is)); Toast.makeText(
                            MainActivity.this,
                            filename,
                            Toast.LENGTH_SHORT
                    ).show();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == INTENT_REQUEST_CODE) {

            if (resultCode == RESULT_OK) {

                try {
                    filename = new File(data.getData().toString()).getName();
                    is = getContentResolver().openInputStream(data.getData());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    public byte[] getBytes(InputStream is) throws IOException {
        ByteArrayOutputStream byteBuff = new ByteArrayOutputStream();
        int buffSize = 1024;
        byte[] buff = new byte[buffSize];
        int len = 0;
        while ((len = is.read(buff)) != -1) {
            byteBuff.write(buff, 0, len);
        }

        return byteBuff.toByteArray();
    }
    private void loginUser(byte[] imageBytes) {


        final String password = etPass.getText().toString().trim();
        RequestBody requestFile = RequestBody.create(MediaType.parse("image/jpeg"), imageBytes);

        MultipartBody.Part body = MultipartBody.Part.createFormData("file", filename+".jpeg", requestFile);
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(PostInterface.JSONURL)
                .addConverterFactory(ScalarsConverterFactory.create())
                .build();
        String username = "0d9a52b3f088957";
        PostInterface api = retrofit.create(PostInterface.class);
        RequestBody username2 = RequestBody.create(MediaType.parse("multipart/form-data"),username);
      //  RequestBody password2 = RequestBody.create(MediaType.parse("multipart/form-data"),password);
        Call<String> call = api.getUserLogin(username2,body);

        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                Log.i("Responsestring", response.body().toString());
                //Toast.makeText()
                if (response.isSuccessful()) {
                    if (response.body() != null) {
                        Log.i("onSuccess", response.body().toString());

                        String jsonresponse = response.body().toString();
                        Toast.makeText(
                                MainActivity.this,
                                "Responce get",
                                Toast.LENGTH_SHORT
                        ).show();
                        parseLoginData(jsonresponse);
                     //   loginUser();


                    } else {
                        Log.i("onEmptyResponse", "Returned empty response");//Toast.makeText(getContext(),"Nothing returned",Toast.LENGTH_LONG).show();
                    }
                }
            }
            @Override
            public void onFailure(Call<String> call, Throwable t) {
                Toast.makeText(
                        MainActivity.this,
                        "Responce fails",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

    }
    public void parseLoginData(String response) {
        Toast.makeText(
                MainActivity.this,
                "Parse Called",
                Toast.LENGTH_SHORT
        ).show();

        try {
            JSONObject jsonObject = new JSONObject(response);
            if (1 == Integer.parseInt(jsonObject.getString("OCRExitCode"))) {
             //   JSONObject result = jsonObject.getJSONObject("ParsedResults");
           //    String  newString = jsonObject.getString("ParsedResults");
             //  JSONObject myjson = new JSONObject(response);
//                Toast.makeText(
//                        MainActivity.this,
//                        jsonObject.getString("message"),
//                        Toast.LENGTH_SHORT
//                ).show();
            //    JSONArray dataArray = jsonObject.getJSONArray("data");
                //   for (int i = 0; i < dataArray.length(); i++) {

                //      JSONObject dataobj = dataArray.getJSONObject(i);
               // firstName = jsonObject.getString("message");
                JSONArray abc = jsonObject.getJSONArray("ParsedResults");
                JSONObject result1 = abc.getJSONObject(0);

              //  String data = abc.getString(3);
               // firstName = result.getString("ParsedText");
                firstName = result1.getString("ParsedText");

                    hobby = "upload";
                   // hobby = dataobj.getString("hobby");
//                }


            }
            Intent intent = new Intent(MainActivity.this,logindemo.class);
            startActivity(intent);
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(
                    MainActivity.this,
                    response,
                    Toast.LENGTH_LONG
            ).show();
        }

    }

}
